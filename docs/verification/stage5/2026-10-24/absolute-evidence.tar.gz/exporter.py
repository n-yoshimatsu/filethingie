from pathlib import Path
import json,hashlib,re,datetime,subprocess,tarfile,gzip,io
base=Path('artifacts/stage5/timed');out=Path('docs/verification/stage5/2026-10-24');entries={};summaries=[]
hash_bytes=lambda b:hashlib.sha256(b).hexdigest()

def redact(value):
 if isinstance(value,list):
  if len(value)==2 and isinstance(value[0],str) and value[0].lower() in ['set-cookie','cookie','x-csrf-token']: return [value[0],'<redacted>']
  return [redact(v) for v in value]
 if isinstance(value,dict):return {k:('<redacted>' if k.lower() in ['set-cookie','cookie','csrf_token','x-csrf-token','ft_pass'] else redact(v)) for k,v in value.items()}
 return value

def clean(p,tokens):
 data=p.read_bytes()
 if p.suffix=='.json':text=json.dumps(redact(json.loads(data)),ensure_ascii=False,indent=2)+'\n'
 else:text=data.decode()
 for token in tokens:text=text.replace(token,'<redacted>')
 return text.encode()

for service in ['php83','php85']:
 p=base/('absolute-'+service)
 r=json.loads((p/'result.json').read_text());checks=json.loads((p/'checks.json').read_text());events=json.loads((p/'http.json').read_text());elapsed=json.loads((p/'elapsed.json').read_text())
 assert r['verdict']=='PASS' and not r['diagnostics'] and r['requests']==len(events)==99 and r['checks']==len(checks)==295
 assert all(c['verdict']=='PASS' and c['actual']==c['expected'] for c in checks)
 active=[c for c in checks if c['check'].startswith('Active session before absolute deadline ')]
 assert [int(c['check'].split()[-1]) for c in active]==list(range(1,95))
 assert checks[-1]['check']=='Real 8-hour absolute expiry' and checks[-1]['actual'] is True
 assert elapsed['seconds']>=28810
 tokens=set()
 for e in events:
  b=(p/e['response_file']).read_bytes()
  assert hash_bytes(b)==e['response_sha256'] and len(b)==e['response_bytes']
  tokens.update(x.decode() for x in re.findall(rb'<meta name="csrf-token" content="([a-f0-9]{64})"',b))
  t=e.get('fields',{}).get('csrf_token');
  if t:tokens.add(t)
  for k,v in e['headers']:
   if k.lower()=='set-cookie':
    m=re.search(r'FTSID[^=]*=([^;]+)',v)
    if m:tokens.add(m[1])
 for e in events[3:-1]:assert b"id='filelist'" in (p/e['response_file']).read_bytes()
 assert b'id="loginbox"' in (p/events[-1]['response_file']).read_bytes()
 log=(p/'container.log').read_text();assert not re.search(r'PHP (?:Fatal error|Parse error|Warning|Deprecated|Notice):',log)
 login_time=datetime.datetime.fromisoformat(r['started_at'])
 logged=[]
 for line in log.splitlines():
  m=re.search(r'\[(\d+/\w+/\d+:\d+:\d+:\d+ [+-]\d+)\] "GET /ft2.php HTTP/1.1" (\d+) (\d+) .*"filethingie-stage3/1"$',line)
  if m:logged.append((datetime.datetime.strptime(m[1],'%d/%b/%Y:%H:%M:%S %z'),int(m[2]),int(m[3])))
 # Shared container log also contains the separate idle trial; select maintained-list responses after the initial minute.
 ticks=[t for t,status,size in logged if (t-login_time).total_seconds()>60 and size==10050 and status==200]
 assert len(ticks)==94
 gaps=[(b-a).total_seconds() for a,b in zip(ticks,ticks[1:])]
 assert min(gaps)>=299 and max(gaps)<=301
 last_gap=(logged[-1][0]-ticks[-1]).total_seconds();assert last_gap<1800
 for f in sorted(p.iterdir()):
  if f.is_file():entries[str(f.relative_to(base))]=clean(f,tokens)
 logpath=base/('absolute-'+service+'.log')
 if logpath.exists():entries[logpath.name]=clean(logpath,tokens)
 source=json.loads((p/'source-sha256.json').read_text());harness=json.loads((p/'harness-sha256.json').read_text())
 for name,sha in source.items():
  data=Path(name).read_bytes();assert hash_bytes(data)==sha;entries['application/'+name]=data
 for name,sha in harness.items():
  data=Path(name).read_bytes()
  if hash_bytes(data)!=sha:data=subprocess.check_output(['git','show',r['parent_commit']+':'+name])
  assert hash_bytes(data)==sha;entries['harness/'+name]=data
 assert all(token.encode() not in data for data in entries.values() for token in tokens)
 summaries.append({'case_id':r['case_id'],'case':'実時間絶対期限','verdict':r['verdict'],'started_at':r['started_at'],'finished_at':r['finished_at'],'php':r['runtime']['php_version'],'environment':'Linux Apacheローカル検証環境','elapsed':elapsed,'active_session_checks':len(active),'checks':len(checks),'requests':len(events),'diagnostics':r['diagnostics'],'access_log_review':{'maintenance_gets':len(ticks),'maintenance_interval_seconds_min':min(gaps),'maintenance_interval_seconds_max':max(gaps),'last_authenticated_get_utc':ticks[-1].isoformat(),'final_get_utc':logged[-1][0].isoformat(),'last_gap_seconds':last_gap,'idle_timeout_seconds':1800,'note':'5分間隔の維持GET94回。最終認証確認は開始約7時間50分後、最終失効確認まで約10分9秒。30分無操作条件への未到達'},'source_files_verified':len(source),'test_plan_note':'開始時の試験計画をハッシュ照合して保存。後日の変更は分離配置ケースTS-517／518の追記、絶対期限の条件変更なし'})
entries['LICENSE']=Path('LICENSE').read_bytes();entries['exporter.py']=Path(__file__).read_bytes()
archive=out/'absolute-evidence.tar.gz'
with archive.open('wb') as stream:
 with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(entries.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
manifest={name:hash_bytes(data) for name,data in sorted(entries.items())}
(out/'absolute-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(out/'absolute-summary.json').write_text(json.dumps(summaries,ensure_ascii=False,indent=2)+'\n')
(out/'absolute-SHA256SUMS').write_text(hash_bytes(archive.read_bytes())+'  '+archive.name+'\n')
with tarfile.open(archive) as tar:assert {m.name:hash_bytes(tar.extractfile(m).read()) for m in tar.getmembers()}==manifest
print(json.dumps({'archive_bytes':archive.stat().st_size,'sha256':hash_bytes(archive.read_bytes()),'cases':len(summaries),'checks':sum(s['checks'] for s in summaries),'requests':sum(s['requests'] for s in summaries),'verdicts':[s['verdict'] for s in summaries]},ensure_ascii=False))
