Disposable Sakura acceptance fixture. Run setup.php from CLI only.
No existing config, files, users or database are read or overwritten.
Production migration and release installation are separate work.
